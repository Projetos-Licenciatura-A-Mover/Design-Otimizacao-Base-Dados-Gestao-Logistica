﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Projeto.Migrations
{
    /// <inheritdoc />
    public partial class Taskupdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "performance_report",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    description = table.Column<string>(type: "text", nullable: false),
                    timestamp = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    moto_id = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_performancereports", x => x.id);
                    table.ForeignKey(
                        name: "fk_performancereports_motorcycles_motoid",
                        column: x => x.moto_id,
                        principalTable: "motorcycles",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "user_motorcycle",
                columns: table => new
                {
                    moto_id = table.Column<int>(type: "integer", nullable: false),
                    user_id = table.Column<int>(type: "integer", nullable: false),
                    motorcycleid = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_user_motorcycle", x => new { x.moto_id, x.user_id });
                    table.ForeignKey(
                        name: "fk_usermotorcycles_motorcycles_motorcycleid",
                        column: x => x.motorcycleid,
                        principalTable: "motorcycles",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_usermotorcycles_users_userid",
                        column: x => x.user_id,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "ix_performancereports_motoid",
                table: "performance_report",
                column: "moto_id");

            migrationBuilder.CreateIndex(
                name: "ix_usermotorcycles_motorcycleid",
                table: "user_motorcycle",
                column: "motorcycleid");

            migrationBuilder.CreateIndex(
                name: "ix_usermotorcycles_userid",
                table: "user_motorcycle",
                column: "user_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "performance_report");

            migrationBuilder.DropTable(
                name: "user_motorcycle");
        }
    }
}
