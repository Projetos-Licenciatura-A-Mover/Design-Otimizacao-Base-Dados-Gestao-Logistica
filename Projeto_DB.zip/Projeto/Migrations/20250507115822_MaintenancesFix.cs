﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Projeto.Migrations
{
    /// <inheritdoc />
    public partial class MaintenancesFix : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "typeid",
                table: "maintenances",
                newName: "type_id");

            migrationBuilder.RenameColumn(
                name: "motoid",
                table: "maintenances",
                newName: "moto_id");

            migrationBuilder.RenameIndex(
                name: "IX_maintenances_motoid",
                table: "maintenances",
                newName: "IX_maintenances_moto_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "type_id",
                table: "maintenances",
                newName: "typeid");

            migrationBuilder.RenameColumn(
                name: "moto_id",
                table: "maintenances",
                newName: "motoid");

            migrationBuilder.RenameIndex(
                name: "IX_maintenances_moto_id",
                table: "maintenances",
                newName: "IX_maintenances_motoid");
        }
    }
}
