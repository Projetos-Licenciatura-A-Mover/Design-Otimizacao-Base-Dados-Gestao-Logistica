﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Projeto.Migrations
{
    /// <inheritdoc />
    public partial class PartialTables : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_locations_tasks_taskid",
                table: "locations");

            migrationBuilder.DropPrimaryKey(
                name: "PK_motorcyclealerts",
                table: "motorcyclealerts");

            migrationBuilder.RenameTable(
                name: "routepoints",
                newName: "route_points");

            migrationBuilder.RenameTable(
                name: "motorcyclealerts",
                newName: "motorcycle_alerts");

            migrationBuilder.RenameTable(
                name: "eventlogs",
                newName: "event_logs");

            migrationBuilder.RenameTable(
                name: "authtokens",
                newName: "auth_tokens");

            migrationBuilder.RenameColumn(
                name: "userid",
                table: "notifications",
                newName: "user_id");

            migrationBuilder.RenameColumn(
                name: "isread",
                table: "notifications",
                newName: "is_read");

            migrationBuilder.RenameColumn(
                name: "taskid",
                table: "locations",
                newName: "task_id");

            migrationBuilder.RenameColumn(
                name: "stoporder",
                table: "route_points",
                newName: "stop_order");

            migrationBuilder.RenameColumn(
                name: "routeid",
                table: "route_points",
                newName: "route_id");

            migrationBuilder.RenameColumn(
                name: "alertid",
                table: "motorcycle_alerts",
                newName: "alert_id");

            migrationBuilder.RenameColumn(
                name: "motoid",
                table: "motorcycle_alerts",
                newName: "moto_id");

            migrationBuilder.RenameColumn(
                name: "userid",
                table: "auth_tokens",
                newName: "user_id");

            migrationBuilder.RenameColumn(
                name: "expiresat",
                table: "auth_tokens",
                newName: "expires_at");

            migrationBuilder.RenameColumn(
                name: "createdat",
                table: "auth_tokens",
                newName: "created_at");

            migrationBuilder.AddPrimaryKey(
                name: "PK_motorcycle_alerts",
                table: "motorcycle_alerts",
                columns: new[] { "moto_id", "alert_id" });

            migrationBuilder.AddForeignKey(
                name: "fk_locations_tasks_taskid",
                table: "locations",
                column: "task_id",
                principalTable: "tasks",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_locations_tasks_taskid",
                table: "locations");

            migrationBuilder.DropPrimaryKey(
                name: "PK_motorcycle_alerts",
                table: "motorcycle_alerts");

            migrationBuilder.RenameTable(
                name: "route_points",
                newName: "routepoints");

            migrationBuilder.RenameTable(
                name: "motorcycle_alerts",
                newName: "motorcyclealerts");

            migrationBuilder.RenameTable(
                name: "event_logs",
                newName: "eventlogs");

            migrationBuilder.RenameTable(
                name: "auth_tokens",
                newName: "authtokens");

            migrationBuilder.RenameColumn(
                name: "user_id",
                table: "notifications",
                newName: "userid");

            migrationBuilder.RenameColumn(
                name: "is_read",
                table: "notifications",
                newName: "isread");

            migrationBuilder.RenameColumn(
                name: "task_id",
                table: "locations",
                newName: "taskid");

            migrationBuilder.RenameColumn(
                name: "stop_order",
                table: "routepoints",
                newName: "stoporder");

            migrationBuilder.RenameColumn(
                name: "route_id",
                table: "routepoints",
                newName: "routeid");

            migrationBuilder.RenameColumn(
                name: "alert_id",
                table: "motorcyclealerts",
                newName: "alertid");

            migrationBuilder.RenameColumn(
                name: "moto_id",
                table: "motorcyclealerts",
                newName: "motoid");

            migrationBuilder.RenameColumn(
                name: "user_id",
                table: "authtokens",
                newName: "userid");

            migrationBuilder.RenameColumn(
                name: "expires_at",
                table: "authtokens",
                newName: "expiresat");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "authtokens",
                newName: "createdat");

            migrationBuilder.AddPrimaryKey(
                name: "PK_motorcyclealerts",
                table: "motorcyclealerts",
                columns: new[] { "motoid", "alertid" });

            migrationBuilder.AddForeignKey(
                name: "fk_locations_tasks_taskid",
                table: "locations",
                column: "taskid",
                principalTable: "tasks",
                principalColumn: "id");
        }
    }
}
