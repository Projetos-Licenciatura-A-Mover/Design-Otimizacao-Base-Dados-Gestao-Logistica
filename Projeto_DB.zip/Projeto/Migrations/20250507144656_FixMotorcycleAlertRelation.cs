﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Projeto.Migrations
{
    /// <inheritdoc />
    public partial class FixMotorcycleAlertRelation : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_motorcyclealerts_motorcycles_motoid",
                table: "motorcycle_alerts");

            migrationBuilder.AddForeignKey(
                name: "fk_motorcyclealerts_motorcycles_motorcycleid",
                table: "motorcycle_alerts",
                column: "moto_id",
                principalTable: "motorcycles",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_motorcyclealerts_motorcycles_motorcycleid",
                table: "motorcycle_alerts");

            migrationBuilder.AddForeignKey(
                name: "fk_motorcyclealerts_motorcycles_motoid",
                table: "motorcycle_alerts",
                column: "moto_id",
                principalTable: "motorcycles",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
