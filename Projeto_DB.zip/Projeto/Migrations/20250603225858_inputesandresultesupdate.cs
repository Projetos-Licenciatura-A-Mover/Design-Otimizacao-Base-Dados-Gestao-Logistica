﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Projeto.Migrations
{
    /// <inheritdoc />
    public partial class inputesandresultesupdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "input_id",
                table: "results",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "inputs",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    name = table.Column<string>(type: "text", nullable: false),
                    content = table.Column<string>(type: "jsonb", nullable: false),
                    is_used = table.Column<bool>(type: "boolean", nullable: false, defaultValue: false),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "NOW()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_inputs", x => x.id);
                });

            migrationBuilder.CreateIndex(
                name: "ix_resultes_inputid",
                table: "results",
                column: "input_id");

            migrationBuilder.AddForeignKey(
                name: "fk_resultes_inputs_inputid",
                table: "results",
                column: "input_id",
                principalTable: "inputs",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_resultes_inputs_inputid",
                table: "results");

            migrationBuilder.DropTable(
                name: "inputs");

            migrationBuilder.DropIndex(
                name: "ix_resultes_inputid",
                table: "results");

            migrationBuilder.DropColumn(
                name: "input_id",
                table: "results");
        }
    }
}
