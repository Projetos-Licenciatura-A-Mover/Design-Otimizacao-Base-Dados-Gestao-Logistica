﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Models
{
   public class ExecuteLogs
    {
        [Key]
        public int Id { get; set; } = 1; // sempre 1 para overwrite

        public string Log { get; set; } // conteúdo JSON do ficheiro

        public DateTime AtualizadoEm { get; set; } = DateTime.UtcNow;

    }
}
