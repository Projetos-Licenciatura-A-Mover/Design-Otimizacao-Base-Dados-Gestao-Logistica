﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Models
{
    public class MotorcycleAlert
    {
        public int MotoId { get; set; }

        public int AlertId { get; set; }

        
        public Motorcycle Motorcycle { get; set; }
        public Alert Alert { get; set; }
    }
}
