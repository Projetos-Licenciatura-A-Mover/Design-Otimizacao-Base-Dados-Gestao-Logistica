﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Models
{
    public class UserAlert
    {
        public int UserId { get; set; }
        public User User { get; set; }

        public int AlertId { get; set; }
        public Alert Alert { get; set; }
    }
}
