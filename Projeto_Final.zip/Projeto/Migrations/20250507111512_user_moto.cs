﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Projeto.Migrations
{
    /// <inheritdoc />
    public partial class user_moto : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_usermotorcycles_motorcycles_motorcycleid",
                table: "user_motorcycle");

            migrationBuilder.DropIndex(
                name: "ix_usermotorcycles_motorcycleid",
                table: "user_motorcycle");

            migrationBuilder.DropColumn(
                name: "motorcycleid",
                table: "user_motorcycle");

            migrationBuilder.AddForeignKey(
                name: "fk_usermotorcycles_motorcycles_motorcycleid",
                table: "user_motorcycle",
                column: "moto_id",
                principalTable: "motorcycles",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_usermotorcycles_motorcycles_motorcycleid",
                table: "user_motorcycle");

            migrationBuilder.AddColumn<int>(
                name: "motorcycleid",
                table: "user_motorcycle",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "ix_usermotorcycles_motorcycleid",
                table: "user_motorcycle",
                column: "motorcycleid");

            migrationBuilder.AddForeignKey(
                name: "fk_usermotorcycles_motorcycles_motorcycleid",
                table: "user_motorcycle",
                column: "motorcycleid",
                principalTable: "motorcycles",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
