﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Projeto.Migrations
{
    /// <inheritdoc />
    public partial class UserAlertsFix : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_useralerts",
                table: "useralerts");

            migrationBuilder.RenameTable(
                name: "useralerts",
                newName: "user_alerts");

            migrationBuilder.RenameColumn(
                name: "alertid",
                table: "user_alerts",
                newName: "alert_id");

            migrationBuilder.RenameColumn(
                name: "userid",
                table: "user_alerts",
                newName: "user_id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_user_alerts",
                table: "user_alerts",
                columns: new[] { "user_id", "alert_id" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_user_alerts",
                table: "user_alerts");

            migrationBuilder.RenameTable(
                name: "user_alerts",
                newName: "useralerts");

            migrationBuilder.RenameColumn(
                name: "alert_id",
                table: "useralerts",
                newName: "alertid");

            migrationBuilder.RenameColumn(
                name: "user_id",
                table: "useralerts",
                newName: "userid");

            migrationBuilder.AddPrimaryKey(
                name: "PK_useralerts",
                table: "useralerts",
                columns: new[] { "userid", "alertid" });
        }
    }
}
