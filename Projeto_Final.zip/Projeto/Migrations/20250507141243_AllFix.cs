﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Projeto.Migrations
{
    /// <inheritdoc />
    public partial class AllFix : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_motorcyclealerts_motorcycles_motorcycleid",
                table: "motorcycle_alerts");

            migrationBuilder.DropForeignKey(
                name: "fk_services_motorcycles_motorcycleid",
                table: "services");

            migrationBuilder.DropIndex(
                name: "ix_routes_taskid",
                table: "routes");

            migrationBuilder.DropIndex(
                name: "ix_motorcyclealerts_motorcycleid",
                table: "motorcycle_alerts");

            migrationBuilder.DropColumn(
                name: "motorcycleid",
                table: "motorcycle_alerts");

            migrationBuilder.RenameTable(
                name: "taskhistories",
                newName: "task_histories");

            migrationBuilder.RenameColumn(
                name: "userid",
                table: "tasks",
                newName: "user_id");

            migrationBuilder.RenameColumn(
                name: "serviceid",
                table: "tasks",
                newName: "service_id");

            migrationBuilder.RenameColumn(
                name: "creationdate",
                table: "tasks",
                newName: "creation_date");

            migrationBuilder.RenameColumn(
                name: "userid",
                table: "services",
                newName: "user_id");

            migrationBuilder.RenameColumn(
                name: "motoid",
                table: "services",
                newName: "moto_id");

            migrationBuilder.RenameIndex(
                name: "IX_services_motoid",
                table: "services",
                newName: "IX_services_moto_id");

            migrationBuilder.RenameColumn(
                name: "taskid",
                table: "routes",
                newName: "task_id");

            migrationBuilder.RenameColumn(
                name: "estimateddeliverytime",
                table: "routes",
                newName: "estimated_delivery_time");

            migrationBuilder.RenameColumn(
                name: "distancekm",
                table: "routes",
                newName: "distance_km");

            migrationBuilder.RenameColumn(
                name: "taskid",
                table: "task_histories",
                newName: "task_id");

            migrationBuilder.AddColumn<int>(
                name: "UserId1",
                table: "tasks",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "AlertId1",
                table: "motorcycle_alerts",
                type: "integer",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_tasks_UserId1",
                table: "tasks",
                column: "UserId1");

            migrationBuilder.CreateIndex(
                name: "ix_routes_taskid",
                table: "routes",
                column: "task_id",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_motorcycle_alerts_AlertId1",
                table: "motorcycle_alerts",
                column: "AlertId1");

            migrationBuilder.AddForeignKey(
                name: "FK_motorcycle_alerts_alerts_AlertId1",
                table: "motorcycle_alerts",
                column: "AlertId1",
                principalTable: "alerts",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_motorcyclealerts_motorcycles_motorcycleid",
                table: "motorcycle_alerts",
                column: "moto_id",
                principalTable: "motorcycles",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_services_motorcycles_motorcycleid",
                table: "services",
                column: "moto_id",
                principalTable: "motorcycles",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_tasks_users_UserId1",
                table: "tasks",
                column: "UserId1",
                principalTable: "users",
                principalColumn: "id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_motorcycle_alerts_alerts_AlertId1",
                table: "motorcycle_alerts");

            migrationBuilder.DropForeignKey(
                name: "fk_motorcyclealerts_motorcycles_motorcycleid",
                table: "motorcycle_alerts");

            migrationBuilder.DropForeignKey(
                name: "fk_services_motorcycles_motorcycleid",
                table: "services");

            migrationBuilder.DropForeignKey(
                name: "FK_tasks_users_UserId1",
                table: "tasks");

            migrationBuilder.DropIndex(
                name: "IX_tasks_UserId1",
                table: "tasks");

            migrationBuilder.DropIndex(
                name: "ix_routes_taskid",
                table: "routes");

            migrationBuilder.DropIndex(
                name: "IX_motorcycle_alerts_AlertId1",
                table: "motorcycle_alerts");

            migrationBuilder.DropColumn(
                name: "UserId1",
                table: "tasks");

            migrationBuilder.DropColumn(
                name: "AlertId1",
                table: "motorcycle_alerts");

            migrationBuilder.RenameTable(
                name: "task_histories",
                newName: "taskhistories");

            migrationBuilder.RenameColumn(
                name: "user_id",
                table: "tasks",
                newName: "userid");

            migrationBuilder.RenameColumn(
                name: "service_id",
                table: "tasks",
                newName: "serviceid");

            migrationBuilder.RenameColumn(
                name: "creation_date",
                table: "tasks",
                newName: "creationdate");

            migrationBuilder.RenameColumn(
                name: "user_id",
                table: "services",
                newName: "userid");

            migrationBuilder.RenameColumn(
                name: "moto_id",
                table: "services",
                newName: "motoid");

            migrationBuilder.RenameIndex(
                name: "IX_services_moto_id",
                table: "services",
                newName: "IX_services_motoid");

            migrationBuilder.RenameColumn(
                name: "task_id",
                table: "routes",
                newName: "taskid");

            migrationBuilder.RenameColumn(
                name: "estimated_delivery_time",
                table: "routes",
                newName: "estimateddeliverytime");

            migrationBuilder.RenameColumn(
                name: "distance_km",
                table: "routes",
                newName: "distancekm");

            migrationBuilder.RenameColumn(
                name: "task_id",
                table: "taskhistories",
                newName: "taskid");

            migrationBuilder.AddColumn<int>(
                name: "motorcycleid",
                table: "motorcycle_alerts",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "ix_routes_taskid",
                table: "routes",
                column: "taskid");

            migrationBuilder.CreateIndex(
                name: "ix_motorcyclealerts_motorcycleid",
                table: "motorcycle_alerts",
                column: "motorcycleid");

            migrationBuilder.AddForeignKey(
                name: "fk_motorcyclealerts_motorcycles_motorcycleid",
                table: "motorcycle_alerts",
                column: "motorcycleid",
                principalTable: "motorcycles",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_services_motorcycles_motorcycleid",
                table: "services",
                column: "motoid",
                principalTable: "motorcycles",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
