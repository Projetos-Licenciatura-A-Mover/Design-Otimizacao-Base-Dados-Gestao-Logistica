﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Projeto.Models;

namespace ProjetoApp
{
    public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<ProjetoDbContext>
    {
        public ProjetoDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<ProjetoDbContext>();

            // Atualiza esta connection string conforme a tua configuração
            optionsBuilder.UseNpgsql("Host=aws-0-eu-west-3.pooler.supabase.com;Port=5432;Database=postgres;Username=postgres.dltmlxkjdrayavhhrebc;Password=1Q_2w_3e_4r;Ssl Mode=Require;Trust Server Certificate=true");

            
    
            return new ProjetoDbContext(optionsBuilder.Options);
        }
    }
}

