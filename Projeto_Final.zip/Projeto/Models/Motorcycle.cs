﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Models
{
    /// <summary>
    /// Represents a motorcycle entity in the system.
    /// </summary>
    public class Motorcycle
    {
        public int Id { get; set; }

        [Required]
        public string Brand { get; set; }

        [Required]
        public string Model { get; set; }

        [Range(0, 100)]
        public int BatteryStatus { get; set; } //status da bateria em % (0-100)
        public double? Km { get; set; }
        public string Status { get; set; }

        public double BatteryCapacity { get; set; } //capacidade da bateria em kWh

        [Range(0, 100)]
        public double BatteryDegradation { get; set; } //degradação da bateria em %

    }
}
