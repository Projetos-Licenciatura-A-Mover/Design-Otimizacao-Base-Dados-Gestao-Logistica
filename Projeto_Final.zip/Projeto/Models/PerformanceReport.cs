﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Models
{
    /// <summary>
    /// Represents a performance report for a motorcycle.
    /// </summary>
    public class PerformanceReport
    {
        public int Id { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        public DateTime Timestamp { get; set; }

        [Required]
        [ForeignKey("Motorcycle")]
        public int MotoId { get; set; }

        public Motorcycle Motorcycle { get; set; }
    }
}
