using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using Projeto.Models;

namespace Projeto.Models
{
    /// <summary>
    /// Represents the database context for the Projeto application, managing the connection to the database and defining the DbSet properties for each entity.
    /// </summary>
    public class ProjetoDbContext : DbContext
    {
        public ProjetoDbContext(DbContextOptions<ProjetoDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<UserType> UserTypes { get; set; }
        public DbSet<TaskEntity> Tasks { get; set; }
        public DbSet<Service> Services { get; set; }
        public DbSet<Motorcycle> Motorcycles { get; set; }
        public DbSet<Route> Routes { get; set; }
        public DbSet<RoutePoint> RoutePoints { get; set; }
        public DbSet<Maintenance> Maintenances { get; set; }
        public DbSet<MaintenanceType> MaintenanceTypes { get; set; }
        public DbSet<Notification> Notifications { get; set; }
        public DbSet<AuthToken> AuthTokens { get; set; }
        public DbSet<Alert> Alerts { get; set; }
        public DbSet<UserAlert> UserAlerts { get; set; }
        public DbSet<MotorcycleAlert> MotorcycleAlerts { get; set; }
        public DbSet<EventLog> EventLogs { get; set; }
        public DbSet<Location> Locations { get; set; }
        public DbSet<TaskHistory> TaskHistories { get; set; }
        public DbSet<PerformanceReport> PerformanceReports { get; set; }
        public DbSet<UserMotorcycle> UserMotorcycles { get; set; }
        public DbSet<Resultes> Resultes { get; set; }
        public DbSet<ExecuteLogs> ExecuteLogs { get; set; }
        public DbSet<Input> Inputs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            // Lowercase names
            foreach (var entity in modelBuilder.Model.GetEntityTypes())
            {
                entity.SetTableName(entity.GetTableName()!.ToLower());
                foreach (var property in entity.GetProperties())
                {
                    property.SetColumnName(property.Name.ToLower());
                }
                foreach (var key in entity.GetKeys())
                {
                    key.SetName(key.GetName()!.ToLower());
                }
                foreach (var fk in entity.GetForeignKeys())
                {
                    fk.SetConstraintName(fk.GetConstraintName()!.ToLower());
                }
                foreach (var index in entity.GetIndexes())
                {
                    index.SetDatabaseName(index.GetDatabaseName()!.ToLower());
                }
            }


            //MaintenanceType
            modelBuilder.Entity<MaintenanceType>()
                .ToTable("maintenance_types");

            modelBuilder.Entity<MaintenanceType>()
                .Property(mt => mt.Type)
                .HasColumnName("type");

            modelBuilder.Entity<MaintenanceType>()
                .Property(mt => mt.Description)
                .HasColumnName("description");

            //User
            modelBuilder.Entity<User>()
                .HasMany(u => u.Tasks)
                .WithOne(t => t.User)
                .HasForeignKey(t => t.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<User>()
                .Property(u => u.TypeId)
                .HasColumnName("type_id");

            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique();

            //UserType
            modelBuilder.Entity<UserType>().ToTable("user_types");

            //UserAlert
            modelBuilder.Entity<UserAlert>()
                .ToTable("user_alerts"); 

            modelBuilder.Entity<UserAlert>()
                .HasKey(ua => new { ua.UserId, ua.AlertId });

            modelBuilder.Entity<UserAlert>()
                .Property(ua => ua.UserId)
                .HasColumnName("user_id");

            modelBuilder.Entity<UserAlert>()
                .Property(ua => ua.AlertId)
                .HasColumnName("alert_id");


            //Service
            modelBuilder.Entity<Service>()
                .ToTable("services");

            modelBuilder.Entity<Service>()
                .Property(s => s.Type)
                .HasColumnName("type");

            modelBuilder.Entity<Service>()
                .Property(s => s.Date)
                .HasColumnName("date");

            modelBuilder.Entity<Service>()
                .Property(s => s.Description)
                .HasColumnName("description");

            modelBuilder.Entity<Service>()
                .Property(s => s.Status)
                .HasColumnName("status");

            modelBuilder.Entity<Service>()
                .Property(s => s.UserId)
                .HasColumnName("user_id");

            modelBuilder.Entity<Service>()
                .Property(s => s.MotoId)
                .HasColumnName("moto_id");

            modelBuilder.Entity<Service>()
                .HasOne(s => s.User)
                .WithMany()
                .HasForeignKey(s => s.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Service>()
                .HasOne(s => s.Motorcycle)
                .WithMany()
                .HasForeignKey(s => s.MotoId)
                .OnDelete(DeleteBehavior.Cascade);


            //Task
            modelBuilder.Entity<TaskEntity>()
                .ToTable("tasks");

            modelBuilder.Entity<TaskEntity>()
                .HasOne(t => t.Service)
                .WithMany()
                .HasForeignKey(t => t.ServiceId)
                .OnDelete(DeleteBehavior.SetNull);

            modelBuilder.Entity<TaskEntity>()
                .HasOne(t => t.User)
                .WithMany()
                .HasForeignKey(t => t.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<TaskEntity>()
                .Property(t => t.Id)
                .HasColumnName("id");

            modelBuilder.Entity<TaskEntity>()
                .Property(t => t.Type)
                .HasColumnName("type");

            modelBuilder.Entity<TaskEntity>()
                .Property(t => t.CreationDate)
                .HasColumnName("creation_date");

            modelBuilder.Entity<TaskEntity>()
                .Property(t => t.Deadline)
                .HasColumnName("deadline");

            modelBuilder.Entity<TaskEntity>()
                .Property(t => t.Description)
                .HasColumnName("description");

            modelBuilder.Entity<TaskEntity>()
                .Property(t => t.Status)
                .HasColumnName("status");

            modelBuilder.Entity<TaskEntity>()
                .Property(t => t.UserId)
                .HasColumnName("user_id");

            modelBuilder.Entity<TaskEntity>()
                .Property(t => t.ServiceId)
                .HasColumnName("service_id");

            modelBuilder.Entity<TaskEntity>()
                .HasMany(t => t.Locations)
                .WithOne(l => l.Task)
                .HasForeignKey(l => l.TaskId);

            modelBuilder.Entity<TaskEntity>()
                .HasOne(t => t.Route)
                .WithOne(r => r.Task)
                .HasForeignKey<Route>(r => r.TaskId);

            modelBuilder.Entity<TaskEntity>()
                .HasMany(t => t.TaskHistories)
                .WithOne(th => th.Task)
                .HasForeignKey(th => th.TaskId);


            //Maintenance
            modelBuilder.Entity<Maintenance>(entity =>
            {
                entity.ToTable("maintenances");

                entity.Property(m => m.MotoId)
                    .HasColumnName("moto_id");

                entity.Property(m => m.TypeId)
                    .HasColumnName("type_id");

                entity.Property(m => m.Date)
                    .HasColumnName("date");

                entity.HasOne(m => m.Motorcycle)
                    .WithMany()
                    .HasForeignKey(m => m.MotoId)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(m => m.Type)
                    .WithMany()
                    .HasForeignKey(m => m.TypeId)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.HasIndex(m => m.MotoId);
            });


            //Motorcycle
            modelBuilder.Entity<Motorcycle>(entity =>
            {
                entity.Property(m => m.BatteryStatus).HasColumnName("battery_status");
                entity.Property(m => m.BatteryCapacity).HasColumnName("battery_capacity");
                entity.Property(m => m.BatteryDegradation).HasColumnName("battery_degradation");
            });


            //UserMotorcycle
            modelBuilder.Entity<UserMotorcycle>()
                .HasKey(um => new { um.MotoId, um.UserId });

            modelBuilder.Entity<UserMotorcycle>()
                .ToTable("user_motorcycle");

            modelBuilder.Entity<UserMotorcycle>()
                .Property(um => um.MotoId)
                .HasColumnName("moto_id");

            modelBuilder.Entity<UserMotorcycle>()
                .Property(um => um.UserId)
                .HasColumnName("user_id");
            modelBuilder.Entity<UserMotorcycle>()
                .HasOne(um => um.Motorcycle)
                .WithMany()
                .HasForeignKey(um => um.MotoId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<UserMotorcycle>()
                .HasOne(um => um.User)
                .WithMany()
                .HasForeignKey(um => um.UserId)
                .OnDelete(DeleteBehavior.Cascade);


            //PerformanceReport
            modelBuilder.Entity<PerformanceReport>()
                .Property(p => p.MotoId)
                .HasColumnName("moto_id");

            modelBuilder.Entity<PerformanceReport>()
                .ToTable("performance_report");


            //Notification
            modelBuilder.Entity<Notification>(entity =>
            {
                entity.ToTable("notifications");

                entity.HasKey(n => n.Id);

                entity.Property(n => n.Id).HasColumnName("id");
                entity.Property(n => n.UserId).HasColumnName("user_id");
                entity.Property(n => n.Message).HasColumnName("message");
                entity.Property(n => n.Timestamp).HasColumnName("timestamp");
                entity.Property(n => n.IsRead).HasColumnName("is_read");

                entity.HasOne(n => n.User)
                      .WithMany()
                      .HasForeignKey(n => n.UserId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasIndex(n => n.UserId);
            });

            //AuthToken

            modelBuilder.Entity<AuthToken>(entity =>
            {
                entity.ToTable("auth_tokens");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id)
                    .HasColumnName("id");

                entity.Property(e => e.UserId)
                    .HasColumnName("user_id");

                entity.Property(e => e.Token)
                    .HasColumnName("token");

                entity.Property(e => e.CreatedAt)
                    .HasColumnName("created_at");

                entity.Property(e => e.ExpiresAt)
                    .HasColumnName("expires_at");

                entity.HasOne(e => e.User)
                    .WithMany()
                    .HasForeignKey(e => e.UserId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            //EventLog
            modelBuilder.Entity<EventLog>(entity =>
            {
                entity.ToTable("event_logs");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id).HasColumnName("id");
                entity.Property(e => e.Type).HasColumnName("type");
                entity.Property(e => e.Message).HasColumnName("message");
                entity.Property(e => e.Timestamp).HasColumnName("timestamp");
                entity.Property(e => e.Source).HasColumnName("source");
            });

            //Location

            modelBuilder.Entity<Location>().ToTable("locations");

            modelBuilder.Entity<Location>()
                .Property(l => l.Id)
                .HasColumnName("id");

            modelBuilder.Entity<Location>()
                .Property(l => l.Timestamp)
                .HasColumnName("timestamp");

            modelBuilder.Entity<Location>()
                .Property(l => l.Latitude)
                .HasColumnName("latitude");

            modelBuilder.Entity<Location>()
                .Property(l => l.Longitude)
                .HasColumnName("longitude");

            modelBuilder.Entity<Location>()
                .Property(l => l.TaskId)
                .HasColumnName("task_id");

            modelBuilder.Entity<Location>()
                .HasOne(l => l.Task)
                .WithMany(t => t.Locations)
                .HasForeignKey(l => l.TaskId)
                .OnDelete(DeleteBehavior.Cascade);

            //MotorcycleAlert
            modelBuilder.Entity<MotorcycleAlert>()
                .HasKey(ma => new { ma.MotoId, ma.AlertId });
            modelBuilder.Entity<MotorcycleAlert>()
                .HasOne(ma => ma.Motorcycle)
                .WithMany()
                .HasForeignKey(ma => ma.MotoId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<MotorcycleAlert>()
                .HasOne(ma => ma.Alert)
                .WithMany()
                .HasForeignKey(ma => ma.AlertId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<MotorcycleAlert>()
                .ToTable("motorcycle_alerts"); 

            modelBuilder.Entity<MotorcycleAlert>()
                .Property(ma => ma.MotoId)
                .HasColumnName("moto_id");

            modelBuilder.Entity<MotorcycleAlert>()
                .Property(ma => ma.AlertId)
                .HasColumnName("alert_id");


            //RoutePoints

            modelBuilder.Entity<RoutePoint>(entity =>
            {
                entity.ToTable("route_points");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id)
                    .HasColumnName("id");

                entity.Property(e => e.RouteId)
                    .HasColumnName("route_id");

                entity.Property(e => e.Latitude)
                    .HasColumnName("latitude");

                entity.Property(e => e.Longitude)
                    .HasColumnName("longitude");

                entity.Property(e => e.StopOrder)
                    .HasColumnName("stop_order");

                entity.HasOne(e => e.Route)
                    .WithMany(r => r.RoutePoints)
                    .HasForeignKey(e => e.RouteId)
                    .OnDelete(DeleteBehavior.Cascade);
            });


            //Route
            modelBuilder.Entity<Route>(entity =>
            {
                entity.ToTable("routes");

                entity.HasKey(r => r.Id);

                entity.Property(r => r.Id)
                    .HasColumnName("id");

                entity.Property(r => r.TaskId)
                    .HasColumnName("task_id");

                entity.Property(r => r.DistanceKm)
                    .HasColumnName("distance_km");

                entity.Property(r => r.EstimatedDeliveryTime)
                    .HasColumnName("estimated_delivery_time");

                entity.HasOne(r => r.Task)
                    .WithOne(t => t.Route)
                    .HasForeignKey<Route>(r => r.TaskId)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.HasMany(r => r.RoutePoints)
                    .WithOne(rp => rp.Route)
                    .HasForeignKey(rp => rp.RouteId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            //TaskHistory
            modelBuilder.Entity<TaskHistory>(entity =>
            {
                entity.ToTable("task_histories");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id).HasColumnName("id");
                entity.Property(e => e.TaskId).HasColumnName("task_id");
                entity.Property(e => e.Status).HasColumnName("status");
                entity.Property(e => e.Timestamp).HasColumnName("timestamp");

                entity.HasOne(e => e.Task)
                      .WithMany(t => t.TaskHistories)
                      .HasForeignKey(e => e.TaskId)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // Resultes

            modelBuilder.Entity<Resultes>(entity =>
            {
                entity.ToTable("results");

                entity.HasKey(r => r.Id);

                entity.Property(r => r.FileOutput)
                      .IsRequired()
                      .HasColumnName("file_output")
                      .HasColumnType("text");

                entity.Property(r => r.AlgorithmName)
                      .IsRequired()
                      .HasColumnName("algorithm_name")
                      .HasColumnType("text");

                entity.Property(r => r.Route)
                      .IsRequired()
                      .HasColumnName("route")
                      .HasColumnType("jsonb"); 

                entity.Property(r => r.Cost)
                      .IsRequired()
                      .HasColumnName("cost")
                      .HasColumnType("double precision");

                entity.Property(e => e.InputId)
                      .HasColumnName("input_id");

                entity.HasOne(e => e.Input)
                      .WithMany()
                      .HasForeignKey(e => e.InputId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.Property(e => e.EstimatedEnergy)
                      .HasColumnName("estimated_energy")
                      .HasColumnType("double precision");
            });

            // ExecuteLogs

            modelBuilder.Entity<ExecuteLogs>(entity =>
            {
                entity.ToTable("execute_logs");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Log)
                      .HasColumnName("log")
                      .HasColumnType("jsonb");

                entity.Property(e => e.AtualizadoEm)
                      .HasColumnName("atualizado_em");
            });

            // Input

            modelBuilder.Entity<Input>(entity =>
            {
                entity.ToTable("inputs");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id)
                      .HasColumnName("id");

                entity.Property(e => e.Name)
                      .IsRequired()
                      .HasColumnName("name")
                      .HasColumnType("varchar");

                entity.Property(e => e.Content)
                      .IsRequired()
                      .HasColumnName("content")
                      .HasColumnType("jsonb");

                entity.Property(e => e.IsUsed)
                     .HasColumnName("is_used")
                     .HasDefaultValue(false);

                entity.Property(e => e.CreatedAt)
                      .HasColumnName("created_at")
                      .HasDefaultValueSql("NOW()");

            });

            base.OnModelCreating(modelBuilder);
        }
    }
}
