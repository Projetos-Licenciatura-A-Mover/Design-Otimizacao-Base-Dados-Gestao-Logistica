﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Models
{
    /// <summary>
    /// Represents the results of an algorithm execution in the system.
    /// </summary>
    public class Resultes
    {
        [Key]
        
        public int Id { get; set; }

        [Required]
       
        public string FileOutput { get; set; }

        [Required]
        
        public string AlgorithmName { get; set; }

        [Required]
        
        public List<int> Route { get; set; }

        [Required]
        
        public double Cost { get; set; }

        public int InputId { get; set; }

        public double? EstimatedEnergy { get; set; }
        public Input Input { get; set; }

    }
}
