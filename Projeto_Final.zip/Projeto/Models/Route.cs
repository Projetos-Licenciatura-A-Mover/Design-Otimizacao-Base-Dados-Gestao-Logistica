﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Models
{
    /// <summary>
    /// Represents a route in the system, which is associated with a specific task.
    /// </summary>
    public class Route
    {
        public int Id { get; set; }
        public int TaskId { get; set; }
        public TaskEntity Task { get; set; }
        public double? DistanceKm { get; set; }
        public TimeSpan? EstimatedDeliveryTime { get; set; }

        public ICollection<RoutePoint> RoutePoints { get; set; }
    }
}
