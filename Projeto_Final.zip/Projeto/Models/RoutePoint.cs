﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Models
{
    /// <summary>
    /// Represents a point in a route for a motorcycle, including its geographical coordinates and order in the route.
    /// </summary>
    public class RoutePoint
    {
        public int Id { get; set; }
        public int RouteId { get; set; }
        public Route Route { get; set; }

        [Required]
        public double Latitude { get; set; }

        [Required]
        public double Longitude { get; set; }

        [Required]
        public int StopOrder { get; set; }
    }
}
