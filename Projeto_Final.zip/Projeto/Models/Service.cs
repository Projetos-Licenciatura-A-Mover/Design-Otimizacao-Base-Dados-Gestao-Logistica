﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Models
{

    /// <summary>
    /// Represents a service record for a motorcycle, including details such as type, date, description, status, and associated user and motorcycle.
    /// </summary>
    public class Service
    {
        public int Id { get; set; }

        [Required]
        public string Type { get; set; }

        [Required]
        public DateTime Date { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        public string Status { get; set; }

        public int UserId { get; set; }
        public User User { get; set; }

        public int MotoId { get; set; }
        public Motorcycle Motorcycle { get; set; }
    }
}
