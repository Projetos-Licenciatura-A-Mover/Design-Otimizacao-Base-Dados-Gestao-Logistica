﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Models
{

    /// <summary>
    /// Represents a task entity in the system, including details such as type, creation date, deadline, description, status, and associated user and service.
    /// </summary>
    public class TaskEntity
    {
        
        public int Id { get; set; }

        [Required]
        public string Type { get; set; }

        [Required]
        public DateTime CreationDate { get; set; }

        public DateTime? Deadline { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        public string Status { get; set; }

        [ForeignKey("User")]
        public int UserId { get; set; }
        public User User { get; set; }

        public int? ServiceId { get; set; }
        public Service Service { get; set; }
        public ICollection<Location> Locations { get; set; }
        public Route Route { get; set; }
        public ICollection<TaskHistory> TaskHistories { get; set; }
    }
}
