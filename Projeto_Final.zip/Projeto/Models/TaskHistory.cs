﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Models
{

    /// <summary>
    /// Represents a history record for a task, including the task ID, status, and timestamp of the change.
    /// </summary>
    public class TaskHistory
    {
        public int Id { get; set; }
        public int TaskId { get; set; }
        public TaskEntity Task { get; set; }

        [Required]
        public string Status { get; set; }

        [Required]
        public DateTime Timestamp { get; set; }
    }
}
