﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Models
{

    /// <summary>
    /// Represents a user in the system, including properties such as ID, name, email, password, user type, and associated tasks.
    /// </summary>
    public class User
    {
        
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string Name { get; set; }

        [Required, MaxLength(100)]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Password { get; set; }

        public int? TypeId { get; set; }
        public UserType Type { get; set; }

        public ICollection<TaskEntity> Tasks { get; set; }
    }
}
