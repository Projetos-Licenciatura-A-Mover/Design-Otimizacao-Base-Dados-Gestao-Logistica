﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Models
{

    /// <summary>
    /// Represents a user alert in the system, linking a user to an alert.
    /// </summary>
    public class UserAlert
    {
        public int UserId { get; set; }
        public User User { get; set; }

        public int AlertId { get; set; }
        public Alert Alert { get; set; }
    }
}
