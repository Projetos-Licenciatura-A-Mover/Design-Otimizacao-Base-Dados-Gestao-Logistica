﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Models
{

    /// <summary>
    /// Represents a user-motorcycle relationship in the system, linking a user to a motorcycle.
    /// </summary>
    public class UserMotorcycle
    {
        public int MotoId { get; set; }
        public int UserId { get; set; }

        public virtual Motorcycle Motorcycle { get; set; }
        public virtual User User { get; set; }
    }
}
