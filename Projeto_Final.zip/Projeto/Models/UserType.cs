﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Models
{

    /// <summary>
    /// Represents a user type in the system, including properties such as ID, type (Admin, Operator, Courier), and associated users.
    /// </summary>
    public class UserType
    {
        public int Id { get; set; }

        [Required, MaxLength(50)]
        [RegularExpression("^(Admin|Operator|Courier)$", ErrorMessage = "Type must be Admin, Operator or Courier")]
        public string Type { get; set; }

        public ICollection<User> Users { get; set; }
    }
}
