﻿using Projeto.Models;
using Microsoft.EntityFrameworkCore;

var options = new DbContextOptionsBuilder<ProjetoDbContext>()
    .UseNpgsql("Host=aws-0-eu-west-3.pooler.supabase.com;Port=5432;Database=postgres;Username=postgres.dltmlxkjdrayavhhrebc;Password=1Q_2w_3e_4r;Ssl Mode=Require;Trust Server Certificate=true") //ligação com a supabase
    .Options;
using var context = new ProjetoDbContext(options);


